#ifndef _CLEAN_H
#define _CLEAN_H
#include "common.h"
using namespace std;
void removeUselessLines(vector<string>& vec);
void removeUselessChars(vector<string>& vec);
void removeLabelLines(vector<string>& vec);

#endif
